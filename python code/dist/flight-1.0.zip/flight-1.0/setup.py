from distutils.core import setup

setup(name='flight',
      version='1.0',
      py_modules=['flightdict','internetflightarrival','internetflightdeparture','launcher']
      )
